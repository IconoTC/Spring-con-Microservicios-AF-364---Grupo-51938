package es.indra.controllers;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.models.Producto;
import es.indra.services.IProductoService;

@RestController
public class ProductoController {
	
	@Autowired
	private IProductoService productoService;
	
	// Con puerto dinamico esto funciona
//	@Value("${server.port}")
//	private Integer port;
	
	@Autowired
	private HttpServletRequest request;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return productoService.consultarTodos()
				.stream()
				.map(prod -> {
					//prod.setPort(port);
					prod.setPort(request.getLocalPort());
					return prod;
				})
				.collect(Collectors.toList());
	}
	
	// http://localhost:8001/buscar/4
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable Long id) throws InterruptedException {
		Producto producto = productoService.buscarProducto(id);
		
		// Si no ha encontrado el producto, la instancia sera vacia
		// entonces lanzaremos una excepcion
		if (producto.getDescripcion() == null) {
			throw new IllegalStateException("Error al buscar el producto");
		}
		
		// Vamos a configurar las llamadas lentas
		// Por defecto, los microservicios esperan un maximo de 1 segundo en obtener la respuesta
		// Si la peticion supera ese segundo devuelve un Timeout
		// Provoco ese error parando la ejecucion 5 segundos
		if (id.equals(6L)) {
			Thread.sleep(5_000);
		}
		
		// Probar el timeout de 1 segundo
		if (id.equals(1L)) {
			Thread.sleep(3_000);
		}
		
		
		//producto.setPort(port);
		producto.setPort(request.getLocalPort());
		return producto;
	}

}









