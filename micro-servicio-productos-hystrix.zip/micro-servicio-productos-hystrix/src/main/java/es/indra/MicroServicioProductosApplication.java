package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import es.indra.persistence.ProductosDAO;

@SpringBootApplication
@EnableEurekaClient
public class MicroServicioProductosApplication implements CommandLineRunner{
	
	@Autowired
	private ProductosDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioProductosApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Cuantos registros tenemos: " + dao.count());
		
		System.out.println("Buscar producto 3: " + dao.findById(3L).get());
		
	}

}
